# Molty Royale Bot Web App

Bot Python untuk farming game Molty Royale dengan dashboard monitoring sederhana.

## Fitur
- **Create Account**: Buat akun dan dapatkan API Key langsung dari dashboard.
- **Auto Farming**: Bot otomatis melakukan `explore` atau `pickup` item setiap 60 detik.
- **Web Dashboard**: Pantau status bot dan log aktivitas secara real-time.
- **Ready for Railway**: Konfigurasi siap pakai untuk deployment di Railway.app.

## Cara Deploy ke Railway
1. Buat akun di [Railway.app](https://railway.app).
2. Klik **New Project** > **Deploy from GitHub repo**.
3. Pilih repository `molty-royale`.
4. Railway akan otomatis mendeteksi Python dan menjalankan `gunicorn app:app`.
5. Tambahkan **Variables** di dashboard Railway:
   - `MOLTY_API_KEY`: API Key Anda (opsional, bisa di-set via dashboard bot).
   - `PORT`: 5000 (Railway biasanya mengatur ini otomatis).

## Cara Menggunakan
1. Buka URL yang diberikan oleh Railway.
2. Gunakan fitur **Create Account** jika belum punya API Key.
3. Klik **Start Bot**, masukkan `Game ID` dan `Agent ID`.
4. Pantau aktivitas bot di bagian **Logs**.
